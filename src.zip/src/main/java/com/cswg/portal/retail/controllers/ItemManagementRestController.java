package com.cswg.portal.retail.controllers;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cswg.portal.retail.controllers.vo.ResponseStatus;
import com.cswg.portal.retail.controllers.vo.ResponseVO;
import com.cswg.portal.retail.domain.ItemAttributesMapper;
import com.cswg.portal.retail.service.ItemAttributeService;
import com.google.gson.GsonBuilder;
import com.cswg.portal.retail.controllers.vo.CustItem;
import com.cswg.portal.retail.controllers.vo.DetailCustItem;
import com.cswg.portal.retail.controllers.vo.ItemAttributes;
import com.cswg.portal.retail.controllers.vo.ItemManagementRequestVO;
import com.cswg.portal.retail.controllers.vo.ItemManagementResponseVO;


@RestController
@RequestMapping("/items/{requestId}/{userId}")///{requestId}/{userId}/{channel}
public class ItemManagementRestController {
	
	@Autowired
	private ItemAttributeService itemService;
	
	
	Timestamp t = new Timestamp(System.currentTimeMillis());
	String json = new GsonBuilder().setDateFormat("MM-dd-yyyy").create().toJson(t);//hh:mm:ss.S
	
	@GetMapping("/search/{storeNbr}/{custItemCode}/{upc}")
	public @ResponseBody ItemManagementResponseVO getContentInfo1(@PathVariable String requestId,@PathVariable String userId,@PathVariable Long storeNbr, @PathVariable String custItemCode,@PathVariable String upc){
		
		ItemManagementResponseVO response = new ItemManagementResponseVO();
		List<CustItem> searchResult = new ArrayList<CustItem>();
        searchResult = itemService.searchItems(storeNbr, custItemCode, upc);
        
        if(null!=searchResult){
        response.setCustItemRes(searchResult);
        response.setResponseId(requestId);
		response.setStatus(ResponseStatus.SUCCESS);
        }
        
		return response;
	}

	@GetMapping("/id")
    public @ResponseBody ItemManagementResponseVO getContentInfo() {
		
		ItemManagementResponseVO response = new ItemManagementResponseVO();
		List<CustItem> searchResult = new ArrayList<CustItem>();
        searchResult = itemService.searchItems((long)820,"CUSTITEM1","UPC1");
        
        response.setCustItemRes(searchResult);
        response.setResponseId("12345");
		response.setStatus(ResponseStatus.SUCCESS);
		
		return response;
	}
	
	@PostMapping("/save")
    public @ResponseBody ResponseVO saveItem(@RequestBody ItemManagementRequestVO request) {
		
		ResponseVO response = new ResponseVO();
		String message = itemService.saveItem(request.getCustItemReq());
		
		if(message.equals("SUCCESS")){
		response.setResponseId(request.getRequestId());
		response.setStatus(ResponseStatus.SUCCESS);				
		response.setMessage(message);
		}
		else{
			response.setResponseId(request.getRequestId());
			response.setStatus(ResponseStatus.ERROR);
		}
        return response;
    }

	private ItemManagementResponseVO dummyResponse() {
		
		ItemManagementResponseVO response = new ItemManagementResponseVO();
		
		response.setResponseId("123456");
		response.setStatus(ResponseStatus.SUCCESS);
		
		List<CustItem> custItemList = new ArrayList<CustItem>();
		CustItem custItem = new CustItem();
		custItem.setCustItemCode("12342334");
		custItem.setCategory("Filters");
		custItem.setDept("Filters");
		custItem.setDescription("description");
		custItem.setPack("2");
		custItem.setSize("2");
		custItem.setUom("uom");
		custItem.setUpc("upc");
		custItem.setBeginDate(json);
		custItem.setCaseCost((long)1.69);
		custItem.setPriceAssoc((long)1.33);
		custItem.setVendor("1345");
		custItem.setUnitCaseCost((long)1.32);
		custItem.setAllow((long)7.00);
		custItem.setUnitAllow((long)8.00);
		custItem.setAllowDate(json);
		custItem.setUnitAllowDate(json);
		custItem.setCurrentNetUnit((long)2);
		custItem.setRequestLabel(2);
		
		List<ItemAttributes> itemAttrList = new ArrayList<ItemAttributes>();
		
		ItemAttributes baseRetailItem1 = new ItemAttributes();
		ItemAttributes baseRetailItem2 = new ItemAttributes();
		ItemAttributes tprRetailItem = new ItemAttributes();
		ItemAttributes adRetailItem = new ItemAttributes();
        
		baseRetailItem1.setRetailType("Base Retail");
		baseRetailItem1.setRetailPrice((long)4.99);
		baseRetailItem1.setMargin((long)45.7);
		baseRetailItem1.setBeginDate(json);
		baseRetailItem1.setEndDate(json);
		itemAttrList.add(baseRetailItem1);
		
		baseRetailItem2.setRetailType("Base Retail(Current)");
		baseRetailItem2.setRetailPrice((long)5.29);
		baseRetailItem2.setMargin((long)23.2);
		baseRetailItem2.setBeginDate(json);
		baseRetailItem2.setEndDate(json);
		itemAttrList.add(baseRetailItem2);

		tprRetailItem.setRetailType("TPR Retail");
		tprRetailItem.setRetailPrice((long)4.39);
		tprRetailItem.setMargin((long)38.3);
		tprRetailItem.setBeginDate(json);
		tprRetailItem.setEndDate(json);
		itemAttrList.add(tprRetailItem);

		adRetailItem.setRetailType("Ad Retail");
		adRetailItem.setRetailPrice((long)4.30);
		adRetailItem.setMargin((long)38.3);
		adRetailItem.setBeginDate(json);
		adRetailItem.setEndDate(json);
		itemAttrList.add(adRetailItem);   
		
		custItem.setDetailItemList(itemAttrList);
		custItemList.add(custItem);
		
		response.setCustItemRes(custItemList);
		
		return response;
			
	}
}
