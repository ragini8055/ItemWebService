package com.cswg.portal.retail.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cswg.portal.retail.controllers.vo.CustItem;
import com.cswg.portal.retail.controllers.vo.DetailCustItem;
import com.cswg.portal.retail.controllers.vo.ItemAttributes;
import com.cswg.portal.retail.domain.ItemAttributesMapper;
import com.cswg.portal.retail.repository.ItemAttributeRepository;

@Component
public class ItemAttributeService {

	@Autowired
	ItemAttributeRepository itemRepository;

	public String saveItem(CustItem item) {
		DateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");

		ItemAttributesMapper itemAttr = new ItemAttributesMapper();

		itemAttr.setId(item.getRecordId());
		itemAttr.setItemId(item.getItemId());
		itemAttr.setStoreId(item.getStoreId());
		itemAttr.setStoreNbr(item.getStoreNum());
		itemAttr.setCustItemCode(item.getCustItemCode());
		itemAttr.setUpc(item.getUpc());
		itemAttr.setVendor(item.getVendor());
		itemAttr.setCategory(item.getCategory());
		itemAttr.setDescription(item.getDescription());
		itemAttr.setDepartment(item.getDept());
		itemAttr.setCaseCost(item.getCaseCost());
		itemAttr.setUnitCost(item.getUnitCaseCost());
		itemAttr.setPack(item.getPack());
		itemAttr.setSize(item.getSize());
		itemAttr.setRecordStatus("UPDATE");
		itemAttr.setCreatedBy(item.getCreatedBy());
		// itemAttr.setCreationDate(item.getCreationDate());
		itemAttr.setUpdatedBy(item.getUpdatedBy());
		itemAttr.setUpdateByLogin(item.getUpdatedLogin());
		// itemAttr.setUpdateDate(item.getUpdatedDate());
		if (null != item.getBaseList()) {
			itemAttr.setUnitRetail1type(item.getBaseList().get(0).getRetailType());
			itemAttr.setUnitRetail1Mult(item.getBaseList().get(0).getMult());
			itemAttr.setUnitRetail1Price(item.getBaseList().get(0).getRetailPrice());
			// itemAttr.setUnitRetail1Start(item.getBaseList().get(0).getBeginDate());
			// itemAttr.setUnitRetail1End(item.getBaseList().get(0).getEndDate());
			// itemAttr.setUnitRetail1Modified(item.getBaseList().get(0).getModifiedDate());
		}
		if (null != item.getTprList()) {
			itemAttr.setUnitRetail2type(item.getTprList().get(0).getRetailType());
			itemAttr.setUnitRetail2Mult(item.getTprList().get(0).getMult());
			itemAttr.setUnitRetail2Price(item.getTprList().get(0).getRetailPrice());
			// itemAttr.setUnitRetail2Start(item.getTprList().get(0).getBeginDate());
			// itemAttr.setUnitRetail2End(item.getTprList().get(0).getEndDate());
			// itemAttr.setUnitRetail2Modified(item.getTprList().get(0).getModifiedDate());
		}
		itemRepository.save(itemAttr);

		return "SUCCESS";
	}

	public List<CustItem> searchItems(Long storeNum, String custItemCode, String upc) {

		List<CustItem> retailResult = new ArrayList<CustItem>();
		List<ItemAttributesMapper> recordItems;
		List<ItemAttributesMapper> itemAttr = new ArrayList<ItemAttributesMapper>();
		List<Long> recordList = new ArrayList<Long>();

		if (!custItemCode.equals("null") && !upc.equals("null") && storeNum != null) {

			itemAttr = itemRepository.findByStoreNbrAndCustItemCodeAndUpc(storeNum, custItemCode, upc);

		} else if (!upc.equals("null") && storeNum != null && custItemCode.equals("null")) {

			itemAttr = itemRepository.findByStoreNbrAndUpc(storeNum, upc);

		} else if (!custItemCode.equals("null") && storeNum != null && upc.equals("null")) {

			itemAttr = itemRepository.findByStoreNbrAndCustItemCode(storeNum, custItemCode);

		}
		for (ItemAttributesMapper recordItem : itemAttr) {

			if (!recordList.contains(recordItem.getRecordId())) {

				recordList.add(recordItem.getRecordId());
				recordItems = new ArrayList<ItemAttributesMapper>();
				recordItems = itemRepository.findByRecordId(recordItem.getRecordId());

				for (ItemAttributesMapper item : recordItems) {

					List<ItemAttributes> detailItemList = new ArrayList<ItemAttributes>();
					List<DetailCustItem> baseList = new ArrayList<DetailCustItem>();
					List<DetailCustItem> tprList = new ArrayList<DetailCustItem>();
					ItemAttributes subItem;
					DetailCustItem baseRetail = new DetailCustItem();
					DetailCustItem tprRetail = new DetailCustItem();
					CustItem custItem = new CustItem();

					if (item.getRecordStatus().equals("NEW")) {
						custItem.setPortalRecordId(item.getId());
						custItem.setRecordId(item.getRecordId());
						custItem.setItemId(item.getItemId());
						custItem.setVendor(item.getVendor());
						custItem.setCustItemCode(item.getCustItemCode());
						custItem.setUpc(item.getUpc());
						custItem.setStoreId(item.getStoreId());
						custItem.setStoreNum(item.getStoreNbr());

						baseRetail.setStoreNum(item.getStoreNbr());
						baseRetail.setVendor(item.getVendor());
						baseRetail.setCustItemCode(item.getCustItemCode());
						baseRetail.setUpc(item.getUpc());
						baseList.add(baseRetail);

						tprRetail.setStoreNum(item.getStoreNbr());
						tprRetail.setVendor(item.getVendor());
						tprRetail.setCustItemCode(item.getCustItemCode());
						tprRetail.setUpc(item.getUpc());
						tprList.add(tprRetail);

						if (null != item.getBaseRetailPrice()) {
							subItem = new ItemAttributes();
							subItem.setRetailType("BASE RETAIL");
							subItem.setRetailPrice(item.getBaseRetailPrice());
							subItem.setMult(item.getBaseRetailMult());
							// subItem.setBeginDate(item.getBaseRetailStart());
							// subItem.setEndDate(item.getBaseRetailEnd());
							detailItemList.add(subItem);
						}

						if (null != item.getCurrentRetailPrice()) {
							subItem = new ItemAttributes();
							subItem.setRetailType(item.getCurrentRetailtype());
							subItem.setRetailPrice(item.getCurrentRetailPrice());
							subItem.setMult(item.getCurrentRetailMult());
							// subItem.setBeginDate(item.getCurrentRetailStart());
							// subItem.setEndDate(item.getCurrentRetailEnd());
							detailItemList.add(subItem);
						}

						if (null != item.getUnitRetail1Price()) {
							subItem = new ItemAttributes();
							subItem.setRetailType(item.getUnitRetail1type());
							subItem.setRetailPrice(item.getUnitRetail1Price());
							subItem.setMult(item.getUnitRetail1Mult());
							// subItem.setBeginDate(item.getUnitRetail1Start());
							// subItem.setEndDate(item.getUnitRetail1End());
							detailItemList.add(subItem);
						}
						
						if (null != item.getUnitRetail2Price()) {
							subItem = new ItemAttributes();
							subItem.setRetailType(item.getUnitRetail2type());
							subItem.setRetailPrice(item.getUnitRetail2Price());
							subItem.setMult(item.getUnitRetail2Mult());
							// subItem.setBeginDate(item.getUnitRetail2Start());
							// subItem.setEndDate(item.getUnitRetail2End());
							detailItemList.add(subItem);
						}
						
						if (null != item.getUnitRetail3Price()) {
							subItem = new ItemAttributes();
							subItem.setRetailType(item.getUnitRetail3type());
							subItem.setRetailPrice(item.getUnitRetail3Price());
							subItem.setMult(item.getUnitRetail3Mult());
							// subItem.setBeginDate(item.getUnitRetail3Start());
							// subItem.setEndDate(item.getUnitRetail3End());
							detailItemList.add(subItem);
						}
					}
					
					if(item.getRecordStatus().equals("UPDATE")){
						
						if (null != item.getUnitRetail1Price()) {
							subItem = new ItemAttributes();
							subItem.setRetailType(item.getUnitRetail1type());
							subItem.setRetailPrice(item.getUnitRetail1Price());
							subItem.setMult(item.getUnitRetail1Mult());
							// subItem.setBeginDate(item.getUnitRetail1Start());
							// subItem.setEndDate(item.getUnitRetail1End());
							detailItemList.add(subItem);
						}
						
						if (null != item.getUnitRetail2Price()) {
							subItem = new ItemAttributes();
							subItem.setRetailType(item.getUnitRetail2type());
							subItem.setRetailPrice(item.getUnitRetail2Price());
							subItem.setMult(item.getUnitRetail2Mult());
							// subItem.setBeginDate(item.getUnitRetail2Start());
							// subItem.setEndDate(item.getUnitRetail2End());
							detailItemList.add(subItem);
						}
					}
					custItem.setBaseList(baseList);
					custItem.setTprList(tprList);
					custItem.setDetailItemList(detailItemList);
					retailResult.add(custItem);
				}
			}

		}

		return retailResult;
	}

}
