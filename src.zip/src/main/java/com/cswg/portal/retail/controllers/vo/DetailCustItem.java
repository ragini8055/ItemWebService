package com.cswg.portal.retail.controllers.vo;


public class DetailCustItem {

    private Long RecordId;
	private String vendor;
    private Long storeNum;
    private String upc;
    private String custItemCode;
    private Long mult;
    private Long margin;
    private Long retailPrice;
    private String beginDate;
    private String endDate;
    private String retailType;
    
	public Long getRecordId() {
		return RecordId;
	}
	public void setRecordId(Long recordId) {
		RecordId = recordId;
	}
	public Long getStoreNum() {
		return storeNum;
	}
	public void setStoreNum(Long storeNum) {
		this.storeNum = storeNum;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getCustItemCode() {
		return custItemCode;
	}
	public void setCustItemCode(String custItemCode) {
		this.custItemCode = custItemCode;
	}
	public Long getMult() {
		return mult;
	}
	public void setMult(Long mult) {
		this.mult = mult;
	}
	public Long getMargin() {
		return margin;
	}
	public void setMargin(Long margin) {
		this.margin = margin;
	}
	public Long getRetailPrice() {
		return retailPrice;
	}
	public void setRetailPrice(Long retailPrice) {
		this.retailPrice = retailPrice;
	}
	public String getRetailType() {
		return retailType;
	}
	public void setRetailType(String retailType) {
		this.retailType = retailType;
	}
    
}
