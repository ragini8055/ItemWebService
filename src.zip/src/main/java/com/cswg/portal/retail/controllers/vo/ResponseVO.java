package com.cswg.portal.retail.controllers.vo;

import com.cswg.portal.retail.controllers.vo.ResponseStatus;
import com.cswg.portal.retail.controllers.vo.ValidationResponseVO;

public class ResponseVO {
	
	private String responseId;
	private String userId;
	private ResponseStatus status;
	private String message;
	private ValidationResponseVO validation;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getResponseId() {
		return responseId;
	}
	public void setResponseId(String responseId) {
		this.responseId = responseId;
	}
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ValidationResponseVO getValidation() {
		return validation;
	}
	public void setValidation(ValidationResponseVO validation) {
		this.validation = validation;
	}	
}
