package com.cswg.portal.retail.controllers.vo;

public enum ResponseStatus {
	INPUT_INVALID, ERROR, SUCCESS;
}
