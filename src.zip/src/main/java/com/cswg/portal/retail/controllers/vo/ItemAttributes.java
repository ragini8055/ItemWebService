package com.cswg.portal.retail.controllers.vo;


public class ItemAttributes {
	
	private Long ipId;
	private String retailType;
	private Long retailPrice;
	private Long margin;
	private Long mult;
	private String beginDate;
	private String endDate;
    private String modifiedDate;


	public Long getIpId() {
		return ipId;
	}
	public void setIpId(Long ipId) {
		this.ipId = ipId;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getRetailType() {
		return retailType;
	}
	public void setRetailType(String retailType) {
		this.retailType = retailType;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Long getRetailPrice() {
		return retailPrice;
	}
	public void setRetailPrice(Long retailPrice) {
		this.retailPrice = retailPrice;
	}
	public Long getMargin() {
		return margin;
	}
	public void setMargin(Long margin) {
		this.margin = margin;
	}
	public Long getMult() {
		return mult;
	}
	public void setMult(Long mult) {
		this.mult = mult;
	}

}
