package com.cswg.portal.retail.controllers.vo;

public class ItemManagementRequestVO extends RequestVO{
	private CustItem custItemReq;

	public CustItem getCustItemReq() {
		return custItemReq;
	}
	public void setCustItemReq(CustItem custItemReq) {
		this.custItemReq = custItemReq;
	}
}
