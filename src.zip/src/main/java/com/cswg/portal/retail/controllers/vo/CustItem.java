package com.cswg.portal.retail.controllers.vo;

import java.util.List;

public class CustItem {
	
	private Long portalRecordId;
	private Long recordId;
	private Long itemId;
	private Long storeId;
	private Long storeNum;
	private Long vendorId;
	private String vendor;
	private String custItemCode;
	private String category;
	private String description;
	private String pack;
	private String size;
	private String uom;
	private String upc;
	private String dept;
	private Long priceAssoc;
	private Long caseCost;
	private Long unitCaseCost;
	private String beginDate; 
    private Long allow;
    private Long unitAllow;
    private String allowDate;
    private String unitAllowDate;
    private int requestLabel;
    private Long currentNetUnit;
    private String recordStatus;
    private String createdBy;
    private String creationDate;
    private String updatedBy;
    private String updatedDate;
    private String updatedLogin;
	private List<ItemAttributes> detailItemList;
    private List<DetailCustItem> baseList;
    private List<DetailCustItem> tprList;
    
	public Long getPortalRecordId() {
		return portalRecordId;
	}

	public void setPortalRecordId(Long portalRecordId) {
		this.portalRecordId = portalRecordId;
	}

	public Long getStoreNum() {
		return storeNum;
	}

	public void setStoreNum(Long storeNum) {
		this.storeNum = storeNum;
	}
	
    public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public Long getStoreId() {
		return storeId;
	}

	public void setStoreId(Long storeId) {
		this.storeId = storeId;
	}

	public int getRequestLabel() {
		return requestLabel;
	}

	public void setRequestLabel(int requestLabel) {
		this.requestLabel = requestLabel;
	}

	public List<ItemAttributes> getDetailItemList() {
		return detailItemList;
	}

	public void setDetailItemList(List<ItemAttributes> detailItemList) {
		this.detailItemList = detailItemList;
	}

	public String getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	
	public Long getAllow() {
		return allow;
	}

	public void setAllow(Long allow) {
		this.allow = allow;
	}

	public String getAllowDate() {
		return allowDate;
	}

	public void setAllowDate(String allowDate) {
		this.allowDate = allowDate;
	}

	public String getUnitAllowDate() {
		return unitAllowDate;
	}

	public void setUnitAllowDate(String unitAllowDate) {
		this.unitAllowDate = unitAllowDate;
	}

	public String getCustItemCode() {
		return custItemCode;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedLogin() {
		return updatedLogin;
	}

	public void setUpdatedLogin(String updatedLogin) {
		this.updatedLogin = updatedLogin;
	}

	public void setCustItemCode(String custItemCode) {
		this.custItemCode = custItemCode;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getPack() {
		return pack;
	}

	public void setPack(String pack) {
		this.pack = pack;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Long getPriceAssoc() {
		return priceAssoc;
	}

	public void setPriceAssoc(Long priceAssoc) {
		this.priceAssoc = priceAssoc;
	}

	public Long getCaseCost() {
		return caseCost;
	}

	public void setCaseCost(Long caseCost) {
		this.caseCost = caseCost;
	}

	public Long getUnitCaseCost() {
		return unitCaseCost;
	}

	public void setUnitCaseCost(Long unitCaseCost) {
		this.unitCaseCost = unitCaseCost;
	}

	public Long getUnitAllow() {
		return unitAllow;
	}

	public Long getVendorId() {
		return vendorId;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public void setUnitAllow(Long unitAllow) {
		this.unitAllow = unitAllow;
	}

	public Long getCurrentNetUnit() {
		return currentNetUnit;
	}

	public void setCurrentNetUnit(Long currentNetUnit) {
		this.currentNetUnit = currentNetUnit;
	}

	public List<DetailCustItem> getBaseList() {
		return baseList;
	}

	public void setBaseList(List<DetailCustItem> baseList) {
		this.baseList = baseList;
	}

	public List<DetailCustItem> getTprList() {
		return tprList;
	}

	public void setTprList(List<DetailCustItem> tprList) {
		this.tprList = tprList;
	}

}
