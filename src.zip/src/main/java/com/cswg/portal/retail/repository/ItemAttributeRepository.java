package com.cswg.portal.retail.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.cswg.portal.retail.domain.ItemAttributesMapper;

@Repository
public interface ItemAttributeRepository extends CrudRepository<ItemAttributesMapper, String> {

	public List<ItemAttributesMapper> findByStoreNbrAndCustItemCodeAndUpc(Long storeNum, String custItemCode, String upc);
	
	public List<ItemAttributesMapper> findByStoreNbrAndCustItemCode(Long storeNum, String custItemCode);
	
	public List<ItemAttributesMapper> findByStoreNbrAndUpc(Long storeNum, String upc);
	
	public List<ItemAttributesMapper> findByRecordId(Long recordId);

}
