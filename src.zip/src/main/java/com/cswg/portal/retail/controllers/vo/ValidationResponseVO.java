package com.cswg.portal.retail.controllers.vo;

import java.util.Map;

public class ValidationResponseVO {
	private Boolean valid;
	private Map<String,String> validationMessage;
	
	public Boolean isValid() {
		return valid;
	}
	public void setValid(Boolean valid) {
		this.valid = valid;
	}
	public Map<String, String> getValidationMessage() {
		return validationMessage;
	}
	public void setValidationMessage(Map<String, String> validationMessage) {
		this.validationMessage = validationMessage;
	}
}
