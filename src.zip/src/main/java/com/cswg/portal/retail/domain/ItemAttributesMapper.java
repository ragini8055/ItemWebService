package com.cswg.portal.retail.domain;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "XXRTL_ORAC2POR_ITEMATTR_STG")
public class ItemAttributesMapper implements Serializable{

	@Id
	@SequenceGenerator(name="XXRTL_SEQ", sequenceName="XXRTL_ORAC2POR_ITEMATTR_SEQ", allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="XXRTL_SEQ")
	@Column(name="PORTAL_RECORD_ID", nullable=false)
	private Long id;
	
	@Column(name="RECORD_ID", nullable=false)
	private Long recordId;
	
	@Column(name="STORE_ID", nullable=false)
	private Long storeId;
	
	@Column(name="ITEM_ID", nullable=false)
	private Long itemId;
	
	@Column(name="STORENBR", nullable=false)
	private Long storeNbr;
	
	@Column(name="V_ID", nullable=false)
	private Long vendorId;
	
	@Column(name="PRIMARY_VENDOR", nullable=false)
	private String vendor;

	@Column(name="SUPPLIERPARTNUMBER", nullable=false)
	private String custItemCode;
	
	@Column(name="UPC")
	private String upc;
	
	@Column(name="CATEGORY")
	private String category;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="ITEMPACK")
	private String pack;
	
	@Column(name="ITEMSIZE")
	private String size;
	
	@Column(name="UOM")
	private String uom;
	
	@Column(name="DEPARTMENT")
	private String department;
	
	@Column(name="CASECOST")
	private Long caseCost;

	@Column(name="UNITCOST")
	private Long unitCost;
	
	@Column(name="RECORD_STATUS")
	private String recordStatus;
	
	@Column(name="ITEMBASERETAIL")
	private Long baseRetailPrice;
	
	@Column(name="ITEMBASERETAIL_MULT")
	private Long baseRetailMult;
	
	@Column(name="ITEMBASERETAIL_START")
	private Date baseRetailStart;
	
	@Column(name="ITEMBASERETAIL_END")
	private Date baseRetailEnd;
	
	@Column(name="ITEMRETAILCURRENT")
	private Long currentRetailPrice;
	
	@Column(name="ITEMRETAILCURRENT_MULT")
	private Long currentRetailMult;
	
	@Column(name="ITEMRETAILCURRENT_START")
	private Date currentRetailStart;
	
	@Column(name="ITEMRETAILCURRENT_END")
	private Date currentRetailEnd;
	
	@Column(name="ITEMRETAILCURRENT_PTTYPE")
	private String currentRetailtype;
	
	@Column(name="ITEMUNITRETAIL1")
	private Long unitRetail1Price;
	
	@Column(name="ITEMUNITRETAIL1_MULT")
	private Long unitRetail1Mult;
	
	@Column(name="ITEMUNITRETAIL1_START")
	private Date unitRetail1Start;
	
	@Column(name="ITEMUNITRETAIL1_END")
	private Date unitRetail1End;
	
	@Column(name="ITEMUNITRETAIL1_PTTYPE")
	private String unitRetail1type;
	
	@Column(name="ITEMUNITRETAIL1_MODIFIEDDATE")
	private Date unitRetail1Modified;
	
	@Column(name="ITEMUNITRETAIL2")
	private Long unitRetail2Price;
	
	@Column(name="ITEMUNITRETAIL2_MULT")
	private Long unitRetail2Mult;
	
	@Column(name="ITEMUNITRETAIL2_START")
	private Date unitRetail2Start;
	
	@Column(name="ITEMUNITRETAIL2_END")
	private Date unitRetail2End;
	
	@Column(name="ITEMUNITRETAIL2_PTTYPE")
	private String unitRetail2type;
	
	@Column(name="ITEMUNITRETAIL2_MODIFIEDDATE")
	private Date unitRetail2Modified;
	
	@Column(name="ITEMUNITRETAIL3")
	private Long unitRetail3Price;
	
	@Column(name="ITEMUNITRETAIL3_MULT")
	private Long unitRetail3Mult;
	
	@Column(name="ITEMUNITRETAIL3_START")
	private Date unitRetail3Start;
	
	@Column(name="ITEMUNITRETAIL3_END")
	private Date unitRetail3End;
	
	@Column(name="ITEMUNITRETAIL3_PTTYPE")
	private String unitRetail3type;
	
	@Column(name="ITEMUNITRETAIL3_MODIFIEDDATE")
	private Date unitRetail3Modified;
	
	@Column(name="CREATION_DATE")
	private Date creationDate;
	
	@Column(name="LAST_UPDATE_DATE")
	private Date updateDate;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="LAST_UPDATED_BY")
	private String updatedBy;
	 
	@Column(name="LAST_UPDATE_LOGIN")
	private String updateByLogin;
	
	
	public Long getRecordId() {
		return recordId;
	}

	public void setRecordId(Long recordId) {
		this.recordId = recordId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPack() {
		return pack;
	}

	public void setPack(String pack) {
		this.pack = pack;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Long getCaseCost() {
		return caseCost;
	}

	public void setCaseCost(Long caseCost) {
		this.caseCost = caseCost;
	}

	public Long getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(Long unitCost) {
		this.unitCost = unitCost;
	}

	public String getRecordStatus() {
		return recordStatus;
	}

	public void setRecordStatus(String recordStatus) {
		this.recordStatus = recordStatus;
	}

	public Long getBaseRetailPrice() {
		return baseRetailPrice;
	}

	public void setBaseRetailPrice(Long baseRetailPrice) {
		this.baseRetailPrice = baseRetailPrice;
	}

	public Long getBaseRetailMult() {
		return baseRetailMult;
	}

	public void setBaseRetailMult(Long baseRetailMult) {
		this.baseRetailMult = baseRetailMult;
	}

	public Date getBaseRetailStart() {
		return baseRetailStart;
	}

	public void setBaseRetailStart(Date baseRetailStart) {
		this.baseRetailStart = baseRetailStart;
	}

	public Date getBaseRetailEnd() {
		return baseRetailEnd;
	}

	public void setBaseRetailEnd(Date baseRetailEnd) {
		this.baseRetailEnd = baseRetailEnd;
	}

	public Long getCurrentRetailPrice() {
		return currentRetailPrice;
	}

	public void setCurrentRetailPrice(Long currentRetailPrice) {
		this.currentRetailPrice = currentRetailPrice;
	}

	public Long getCurrentRetailMult() {
		return currentRetailMult;
	}

	public void setCurrentRetailMult(Long currentRetailMult) {
		this.currentRetailMult = currentRetailMult;
	}

	public Date getCurrentRetailStart() {
		return currentRetailStart;
	}

	public void setCurrentRetailStart(Date currentRetailStart) {
		this.currentRetailStart = currentRetailStart;
	}

	public Date getCurrentRetailEnd() {
		return currentRetailEnd;
	}

	public void setCurrentRetailEnd(Date currentRetailEnd) {
		this.currentRetailEnd = currentRetailEnd;
	}

	public String getCurrentRetailtype() {
		return currentRetailtype;
	}

	public void setCurrentRetailtype(String currentRetailtype) {
		this.currentRetailtype = currentRetailtype;
	}

	public Long getUnitRetail1Price() {
		return unitRetail1Price;
	}

	public void setUnitRetail1Price(Long unitRetail1Price) {
		this.unitRetail1Price = unitRetail1Price;
	}

	public Long getUnitRetail1Mult() {
		return unitRetail1Mult;
	}

	public void setUnitRetail1Mult(Long unitRetail1Mult) {
		this.unitRetail1Mult = unitRetail1Mult;
	}

	public Date getUnitRetail1Start() {
		return unitRetail1Start;
	}

	public void setUnitRetail1Start(Date unitRetail1Start) {
		this.unitRetail1Start = unitRetail1Start;
	}

	public Date getUnitRetail1End() {
		return unitRetail1End;
	}

	public void setUnitRetail1End(Date unitRetail1End) {
		this.unitRetail1End = unitRetail1End;
	}

	public String getUnitRetail1type() {
		return unitRetail1type;
	}

	public void setUnitRetail1type(String unitRetail1type) {
		this.unitRetail1type = unitRetail1type;
	}

	public Date getUnitRetail1Modified() {
		return unitRetail1Modified;
	}

	public void setUnitRetail1Modified(Date unitRetail1Modified) {
		this.unitRetail1Modified = unitRetail1Modified;
	}

	public Long getUnitRetail2Price() {
		return unitRetail2Price;
	}

	public void setUnitRetail2Price(Long unitRetail2Price) {
		this.unitRetail2Price = unitRetail2Price;
	}

	public Long getUnitRetail2Mult() {
		return unitRetail2Mult;
	}

	public void setUnitRetail2Mult(Long unitRetail2Mult) {
		this.unitRetail2Mult = unitRetail2Mult;
	}

	public Date getUnitRetail2Start() {
		return unitRetail2Start;
	}

	public void setUnitRetail2Start(Date unitRetail2Start) {
		this.unitRetail2Start = unitRetail2Start;
	}

	public Date getUnitRetail2End() {
		return unitRetail2End;
	}

	public void setUnitRetail2End(Date unitRetail2End) {
		this.unitRetail2End = unitRetail2End;
	}

	public String getUnitRetail2type() {
		return unitRetail2type;
	}

	public void setUnitRetail2type(String unitRetail2type) {
		this.unitRetail2type = unitRetail2type;
	}

	public Date getUnitRetail2Modified() {
		return unitRetail2Modified;
	}

	public void setUnitRetail2Modified(Date unitRetail2Modified) {
		this.unitRetail2Modified = unitRetail2Modified;
	}

	public Long getUnitRetail3Price() {
		return unitRetail3Price;
	}

	public void setUnitRetail3Price(Long unitRetail3Price) {
		this.unitRetail3Price = unitRetail3Price;
	}

	public Long getUnitRetail3Mult() {
		return unitRetail3Mult;
	}

	public void setUnitRetail3Mult(Long unitRetail3Mult) {
		this.unitRetail3Mult = unitRetail3Mult;
	}

	public Date getUnitRetail3Start() {
		return unitRetail3Start;
	}

	public void setUnitRetail3Start(Date unitRetail3Start) {
		this.unitRetail3Start = unitRetail3Start;
	}

	public Date getUnitRetail3End() {
		return unitRetail3End;
	}

	public void setUnitRetail3End(Date unitRetail3End) {
		this.unitRetail3End = unitRetail3End;
	}

	public String getUnitRetail3type() {
		return unitRetail3type;
	}

	public void setUnitRetail3type(String unitRetail3type) {
		this.unitRetail3type = unitRetail3type;
	}

	public Date getUnitRetail3Modified() {
		return unitRetail3Modified;
	}

	public void setUnitRetail3Modified(Date unitRetail3Modified) {
		this.unitRetail3Modified = unitRetail3Modified;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdateByLogin() {
		return updateByLogin;
	}

	public void setUpdateByLogin(String updateByLogin) {
		this.updateByLogin = updateByLogin;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getStoreId() {
		return storeId;
	}

	public void setStoreId(Long storeId) {
		this.storeId = storeId;
	}

	public Long getVendorId() {
		return vendorId;
	}

	public void setVendorId(Long vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}
	
	public Long getStoreNbr() {
		return storeNbr;
	}

	public void setStoreNbr(Long storeNbr) {
		this.storeNbr = storeNbr;
	}

	public String getCustItemCode() {
		return custItemCode;
	}

	public void setCustItemCode(String custItemCode) {
		this.custItemCode = custItemCode;
	}

	public String getUpc() {
		return upc;
	}

	public void setUpc(String upc) {
		this.upc = upc;
	}

	
}
