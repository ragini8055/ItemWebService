package com.cswg.portal.retail;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class ItemManagementServiceApplication extends SpringBootServletInitializer{
	
	public static void main(String[] args) {
		SpringApplication.run(ItemManagementServiceApplication.class, args);
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder)
	{
	    return builder.sources(ItemManagementServiceApplication.class);
	}
}
