package com.cswg.portal.retail.controllers.vo;

import java.util.List;

public class ItemManagementResponseVO extends ResponseVO{

	private List<CustItem> custItemRes;

	public List<CustItem> getCustItemRes() {
		return custItemRes;
	}
	public void setCustItemRes(List<CustItem> custItemRes) {
		this.custItemRes = custItemRes;
	}

}
